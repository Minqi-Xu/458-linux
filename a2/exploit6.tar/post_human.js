const formData = new FormData();
formData.append("title","Q6b");
formData.append("content","Q6b_makepost");
formData.append("type",1);
formData.append("form","content");
fetch(window.location.pathname+"/../post.php", {
    method: "POST",
    body: formData,
});